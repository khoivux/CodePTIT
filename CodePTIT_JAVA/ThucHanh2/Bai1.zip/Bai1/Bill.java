package ThucHanh2.Bai1;

public class Bill {
	private String id;
	private Customer customer;
	private Item item;
	private int quantity;
	private static int cnt = 0;
	
	public Bill(Customer customer, Item item, int quantity) {
		cnt++;
		this.id = String.format("HD%03d", cnt);
		this.customer = customer;
		this.item = item;
		this.quantity = quantity;
	}
	public Long getPay() {
		return (long) item.getSellPrice() * quantity;
	}
	public String toString() {
		return id + " " + customer.toString() + " " + item.toString()
			+ " " + quantity + " " + getPay();
	}
}
