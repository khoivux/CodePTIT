package ThucHanh2.Bai1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Main {
	public static void main(String[] args) throws ParseException, FileNotFoundException {
		//Scanner in = new Scanner(System.in);
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Map<String, Customer> mapC = new TreeMap<>();
		Map<String, Item> mapIt = new TreeMap<>();
		
		Scanner in = new Scanner(new FileInputStream("KH.in"));
		int t = Integer.parseInt(in.nextLine());
		while(t-- > 0) {
			Customer c = new Customer(in.nextLine(), in.nextLine(), 
									sdf.parse(in.nextLine()), in.nextLine());
			mapC.put(c.getId(), c);
		}
		
		in = new Scanner(new FileInputStream("MH.in"));
		t = Integer.parseInt(in.nextLine());
		while(t-- > 0) {
			Item it = new Item(in.nextLine(), in.nextLine(),
								Integer.parseInt(in.nextLine()), Integer.parseInt(in.nextLine()));
			mapIt.put(it.getId(), it);
		}
		
		in = new Scanner(new FileInputStream("HD.in"));
		t = Integer.parseInt(in.nextLine());
		while(t-- > 0) {
			Bill b = new Bill(mapC.get(in.next()), mapIt.get(in.next()), Integer.parseInt(in.next()));
			System.out.println(b);
		}
	}
}
//2
//nguyen van nam
//nam 
//12/12/1997
//mo lao ha dong
//tran van binh
//nu
//11/14/1999
//phung khonag
//2
//ao phong tre em
//cai 
//25000
//41000
//ao khoac nam
//cai
//240000
//515000
//3
//KH001 MH001 2
//KH001 MH002 3
//KH002 MH002 4