package ThucHanh2.Bai1;

import java.util.Date;

public class Customer {
	private static int cnt = 0;
	private String id, name, gender, address;
	private Date birth;
	public Customer(String name, String gender, Date birth, String address) {
		cnt++;
		this.id = String.format("KH%03d", cnt);
		this.name = name;
		this.gender = gender;
		this.address = address;
		this.birth = birth;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String toString() {
		return name + " " + address;
	}
}
