package ThucHanh2.Bai1;

public class Item {
	private static int cnt = 0;
	private String id, name, unit;
	private int buyPrice, sellPrice;
	public Item(String name, String unit, Integer buyPrice, Integer sellPrice) {
		super();
		cnt++;
		this.id = String.format("MH%03d", cnt);
		this.name = name;
		this.unit = unit;
		this.buyPrice = buyPrice;
		this.sellPrice = sellPrice;
	}
	
	public String getId() {
		return id;
	}

	public int getSellPrice() {
		return sellPrice;
	}

	public String toString() {
		return name + " " + unit + " " + buyPrice + " " + sellPrice;
	}
}
